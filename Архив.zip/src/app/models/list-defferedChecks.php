<?php //include $_SERVER["DOCUMENT_ROOT"] . "/app/database/db.php";
//tt(selectAll('doc_check_main', ['check_status_id' => 1]));
?>
<div class="wrapper">

    <div class="content">
        <div class="search-box">
            <input type="text" placeholder="Search" class="form-control">
        </div>
        <div class="catalog">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col" class="col">Номер чеку</th>
                        <th scope="col" class="col">Дата Чеку</th>
                        <th scope="col" class="col">Дисконт</th>
                        <th scope="col" class="col">Магазин</th>
                        <th scope="col" class="col">Сума</th>
                    </tr>
                </thead>
                <tbody id="catalogRows">
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                    <tr>
                        <td>ASD123</td>
                        <td>Кофе</td>
                        <td>Напій</td>
                        <td>Мелена кава</td>
                        <td>120 грн.</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</div>